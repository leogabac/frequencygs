# FrequencyGS paper plotting bundle

Contains inputs for Figures 2–6 and the zero-field extra figure, plus clean
copies of their current notebooks. Figure 4 and Figure 5 share figure4.ipynb.
No external disk, raw simulation trajectories, or simulation package is needed.

Keep this folder layout. Open src/notebooks and run each notebook from top to
bottom. Outputs are written to data/figures/paper (extra/ for supporting figures).

Python dependencies: numpy, pandas, matplotlib, scipy, IPython, Jupyter.
Notebook text uses Matplotlib usetex: a working LaTeX installation (including
Computer Modern and the Matplotlib TeX dependencies) is required.

Inputs:
- data/test11/10: averaged vertex populations, per-realization mean H/V
  displacement, and instantaneous H/V occupation counts.
- data/figures/paper: compact temperature/order and phase-boundary tables;
  NPZ contains the four single-particle trace panels (required for Figure 4).
- data/figures/paper/extra: zero-field correlations, fitted times, bootstrap
  samples, endpoint summaries, and method metadata.
- src/py/figure5_regimes.py: descriptive width fitting used by figure4.ipynb.

Existing provenance JSON files retain original source paths for documentation;
these paths are not runtime dependencies. MANIFEST.json records archive files,
byte sizes, SHA256 hashes, and CSV row counts. SHA256SUMS can be checked with
`sha256sum -c SHA256SUMS` from this folder.

No summary table or observable has been re-estimated for this archive.
